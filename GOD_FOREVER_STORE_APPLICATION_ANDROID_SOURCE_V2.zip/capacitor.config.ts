import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.godforever.store',
  appName: 'GOD FOREVER STORE',
  webDir: 'www',
  server: {
    url: 'https://god-forever-ebook-store.samskalonda.workers.dev/',
    cleartext: false,
    allowNavigation: ['god-forever-ebook-store.samskalonda.workers.dev', '*.workers.dev', '*.supabase.co']
  },
  plugins: {
    SplashScreen: { launchShowDuration: 1800, backgroundColor: '#061a34', showSpinner: false },
    StatusBar: { backgroundColor: '#061a34', style: 'DARK' }
  },
  android: { allowMixedContent: false }
};
export default config;
